﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePlan_Entity
{
    public class InsurancePlan
    {
        public string PlanNo
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public string Description
        {
            get;
            set;
        }
        public string DeathBenefit
            {
            get;
            set;
            }
        public string MaturityBenefit
        {
            get;
            set;
        }
        public string ParticipationInProfits
        {
            get;
            set;
        }
        public PlanParameters PlanParameters
        {
            get;
            set;
        }

        //planparameters entity

        //public int AgeofEntry
        //{
        //    get;
        //    set;
        //}
        //public string PremiumPayingMode
        //{
        //    get;
        //    set;
        //}
        //public int PolicyTerm
        //{
        //    get;
        //    set;
        //}
        //public string BasicSumAssured
        //{
        //    get;
        //    set;
        //}
        //public string PolicyRevival
        //{
        //    get;
        //    set;
        //}
        //public string PremiumModeRebate
        //{
        //    get;
        //    set;
        //}
        //public string Loan
        //{
        //    get;
        //    set;
        //}
        //public string Surrender
        //{
        //    get;
        //    set;
        //}
    }
}
