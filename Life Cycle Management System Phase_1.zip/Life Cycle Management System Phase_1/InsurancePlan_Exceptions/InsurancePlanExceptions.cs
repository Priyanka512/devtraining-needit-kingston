﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePlan_Exceptions
{
    public class InsurancePlanExceptions : ApplicationException
    {
        public InsurancePlanExceptions() :
            base()
        {

        }
        public InsurancePlanExceptions(string message) :
            base(message)
        {

        }
        public InsurancePlanExceptions(string message, Exception innerException) : 
            base(message, innerException)
        {

        }
    }
}
