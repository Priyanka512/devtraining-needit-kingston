﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using InsurancePlan_Entity;
using InsurancePlan_Exceptions;
using Insurance_DAL;

namespace Insurance_BAL
{
    public class InsuranceBAL
    {
		private static bool ValidatePlan(InsurancePlan plan)
		{
			bool planValidated = true;
			StringBuilder sb = new StringBuilder();
			if (plan.PlanNo == string.Empty)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan No should be Provided");
			}
			else if (!Regex.IsMatch(plan.PlanNo, @"^[A-Z]{2}[-][0-9]{4}"))
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Should be 7 characters long !With first 2 characters upper case letters followed by hyphen and then 4 digits ");
			}
			if (plan.Name == string.Empty)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan Name should be Provided");
			}
			if (plan.DeathBenefit == string.Empty)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan DeathBenefit should be Provided");
			}
			if (plan.Description == string.Empty)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan Description should be Provided");
			}
			if (plan.MaturityBenefit == string.Empty)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan MaturityBenefit should be Provided");
			}
			if (plan.ParticipationInProfits == string.Empty)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan ParticipationInProfits should be Provided");
			}
			if (Convert.ToString(plan.PlanParameters).Length < 0)
			{
				planValidated = false;
				sb.Append(Environment.NewLine + "Plan PlanParameters should be Provided");
			}
            //PlanParameters Entity

            if (Convert.ToString(plan.PlanParameters.AgeofEntry).Length == 0)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan Age Should be provided");
            }
            else if (plan.PlanParameters.AgeofEntry <= 18 && plan.PlanParameters.AgeofEntry >= 50)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Age Of Entry  should be between 18 and 50");
            }
            if (Convert.ToString(plan.PlanParameters.PolicyTerm).Length == 0)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan PolicyTerm Should be provided");
            }
            else if (plan.PlanParameters.PolicyTerm <= 18 && plan.PlanParameters.AgeofEntry >= 35)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Policy Term  should be between 18 and 35");
            }
            if (Convert.ToString(plan.PlanParameters.BasicSumAssured).Length == 0)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan BasicSumAssured should be Provided");
            }
            if (plan.PlanParameters.PolicyRevival == string.Empty)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan PolicyRevival should be Provided");
            }
            if (plan.PlanParameters.PremiumPayingMode == string.Empty)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan PremiumPayingMode should be Provided");
            }
            else if (plan.PlanParameters.PremiumPayingMode != "Yearly" &&
                plan.PlanParameters.PremiumPayingMode != "HalfYearly" &&
                plan.PlanParameters.PremiumPayingMode != "Quarterly")
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan Premium paying mode  must be in correct format");
            }           
            if (plan.PlanParameters.Loan == string.Empty)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan Loan should be Provided");
            }
            if (plan.PlanParameters.Surrender == string.Empty)
            {
                planValidated = false;
                sb.Append(Environment.NewLine + "Plan Surrender should be Provided");
            }
            if (planValidated == false)
			{
				throw new InsurancePlanExceptions(sb.ToString());
			}
			return planValidated;
		}


		public static bool AddPlanBAL(InsurancePlan Plan)
        {
            bool planAdded = true;
            try
            {
				if (ValidatePlan(Plan))
				{
					InsuranceDAL PlanDAL = new InsuranceDAL();
					planAdded = PlanDAL.AddPlanDAL(Plan);
				}
				else
				{
					throw new InsurancePlanExceptions("Please provide valid plan details");
				}
            }
            catch (InsurancePlanExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return planAdded;
        }

        public static bool ModifyPlanBAL(InsurancePlan Plan)
        {
            bool planUpdated = true;
            try
            {
				if (ValidatePlan(Plan))
				{
					InsuranceDAL PlanDAL = new InsuranceDAL();
					planUpdated = PlanDAL.ModifyPlanDAL(Plan);
				}
				else
				{
					throw new InsurancePlanExceptions("Please provide valid plan details");
				}
            }
            catch (InsurancePlanExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return planUpdated;
        }


        public static bool RemovePlanBAL(string planNo)
        {
            bool planDeleted = true;
            try
            {
                InsuranceDAL PlanDAL = new InsuranceDAL();
                planDeleted = PlanDAL.RemovePlanDAL(planNo);
            }
            catch (InsurancePlanExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return planDeleted;
        }

        public static List<InsurancePlan> GetPlanDetailsBAL()
        {
            List<InsurancePlan> plan = null;
            try
            {
                InsuranceDAL PlanDAL = new InsuranceDAL();
                plan = PlanDAL.GetPlanDetailsDAL();
            }
            catch (InsurancePlanExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return plan;
        }

        public static InsurancePlan SearchPlanBAL(string planNo)
        {
            InsurancePlan plan = null;
            try
            {
                InsuranceDAL PlanDAL = new InsuranceDAL();
                plan = PlanDAL.SearchPlanDAL(planNo);
            }
            catch (InsurancePlanExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return plan;
        }
    }
}
