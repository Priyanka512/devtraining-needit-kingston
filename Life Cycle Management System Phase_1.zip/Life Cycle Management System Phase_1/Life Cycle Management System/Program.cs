﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePlan_Entity;
using InsurancePlan_Exceptions;
using Insurance_BAL;

namespace Life_Cycle_Management_System
{
    class Program
    {
		private static void PrintPlanDetails()
		{
			Console.WriteLine("***********Insurance Plan Details*********");
			Console.WriteLine("Enter Your Option");
			Console.WriteLine("1.Administrator");
			Console.WriteLine("2.Customer");
			Console.WriteLine("******************************************\n");
		}

		private void AcceptPlanDetails()
		{
			char ch;
			do
			{
				PrintPlanDetails();
				int option;
				Console.WriteLine("Enter your Option:");
				option = Convert.ToInt32(Console.ReadLine());
				switch (option)
				{
					case 1:
						AdministratorPlanDetails();
						break;
					case 2:
						CustomerPlanDetails();
						break;
					case 3:
						Environment.Exit(0);
						break;
					default:
						Console.WriteLine("Invalid Choice");
						break;
				}

				Console.WriteLine("y for catalog and N for exit");
				ch = Convert.ToChar(Console.ReadLine());
			} while (ch == 'y' || ch == 'Y');

		}
		private static void PrintAdministratorPlanDetails()
		{
			Console.WriteLine("\n***********Administrator Plan Details***********");		
			Console.WriteLine("1.AddPlan");
			Console.WriteLine("2.ModifyPlan");
			Console.WriteLine("3.RemovePlan ");
			Console.WriteLine("4.GetPlanDetails");
			Console.WriteLine("5.SearchPlan");
			Console.WriteLine("6. Exit");
			Console.WriteLine("************************************************\n");

		}

		private static void PrintCustomerPlanDetails()
		{
			Console.WriteLine("\n***********Customer Plan Details***********");		
			Console.WriteLine("1.GetPlanDetails");
			Console.WriteLine("2.SearchPlan");
			Console.WriteLine("3.Exit");
			Console.WriteLine("********************************************\n");

		}

		private void AdministratorPlanDetails()
		{
			PrintAdministratorPlanDetails();
			char ch;
			do
			{				
				int option;
				Console.WriteLine("Enter your Option:");
				option = Convert.ToInt32(Console.ReadLine());
				switch (option)
				{
					case 1:
						AddPlan();
						break;
					case 2:
						ModifyPlan();
						break;
					case 3:
						RemovePlan();
						break;
					case 4:
						GetPlanDetails();
						break;
					case 5:
						SearchPlan();
						break;
					case 6:
						Environment.Exit(0);
						break;
					default:
						Console.WriteLine("Invalid Choice");
						break;
				}
				Console.WriteLine("y for catalog and N for exit");
				ch = Convert.ToChar(Console.ReadLine());
			} while (ch == 'y' || ch == 'Y');
		}

		private void CustomerPlanDetails()
		{
			PrintCustomerPlanDetails();
			char ch;
			do
			{
				int option;
				Console.WriteLine("Enter your Option:");
				option = Convert.ToInt32(Console.ReadLine());
				switch (option)
				{
					case 1:
						GetPlanDetails();
						break;
					case 2:
						SearchPlan();
						break;
					case 3:
						Environment.Exit(0);
						break;
					default:
						Console.WriteLine("Invalid Choice");
						break;
				}
				Console.WriteLine("y for catalog and N for exit");
				ch = Convert.ToChar(Console.ReadLine());
			} while (ch == 'y' || ch == 'Y');
		}
		private static void AddPlan()
        {            
            try
            {
                InsurancePlan plan = new InsurancePlan();
                Console.WriteLine("Enter the  Plan no:");
                plan.PlanNo = Console.ReadLine();
                Console.WriteLine("Enter the Plan Name:");
                plan.Name = Console.ReadLine();
                Console.WriteLine("Enter the Plan Description:");
                plan.Description = Console.ReadLine();
                Console.WriteLine("Enter the Plan DeathBenefit:");
                plan.DeathBenefit = Console.ReadLine();
                Console.WriteLine("Enter the Plan MaturityBenefit:");
                plan.MaturityBenefit = Console.ReadLine();
                Console.WriteLine("Enter the Plan ParticipationInProfits:");
                plan.ParticipationInProfits = Console.ReadLine();

                PlanParameters PlanParam = new PlanParameters();

                Console.WriteLine("Enter the  Plan Age of Entry:");
                PlanParam.AgeofEntry = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Plan PremiumPayingMode:");
                PlanParam.PremiumPayingMode = Console.ReadLine();
                Console.WriteLine("Enter the  Plan Policy Term:");
                PlanParam.PolicyTerm = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Plan Basic Sum Assured:");
                PlanParam.BasicSumAssured = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Plan Policy Revival:");
                PlanParam.PolicyRevival = Console.ReadLine();
                Console.WriteLine("Enter the Plan Premium Mode Rebate:");
                PlanParam.PremiumModeRebate = Console.ReadLine();
                Console.WriteLine("Enter the Plan Loan:");
                PlanParam.Loan = Console.ReadLine();
                Console.WriteLine("Enter the Plan Surrender:");
                PlanParam.Surrender = Console.ReadLine();
                plan.PlanParameters = PlanParam;              
                bool planAdded = InsuranceBAL.AddPlanBAL(plan);
                if (planAdded)
                {
                    Console.WriteLine("Plan Details Added Successfully...");
                }
                else
                    Console.WriteLine("Plan Details not Added...");
            }
            catch (InsurancePlanExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }

        private static void ModifyPlan()
        {
            try
            {
                string modifyPlanNo;
                Console.WriteLine("Enter Plan No to Update Details:");
                modifyPlanNo = Console.ReadLine();
                InsurancePlan updatedPlan = InsuranceBAL.SearchPlanBAL(modifyPlanNo);
                if (updatedPlan != null)
                {
                    Console.WriteLine("Enter the Plan Name:");
                    updatedPlan.Name = Console.ReadLine();
                    Console.WriteLine("Enter the Plan Description:");
                    updatedPlan.Description = Console.ReadLine();
                    Console.WriteLine("Enter the Plan DeathBenefit:");
                    updatedPlan.DeathBenefit = Console.ReadLine();
                    Console.WriteLine("Enter the Plan MaturityBenefit:");
                    updatedPlan.MaturityBenefit = Console.ReadLine();
                    Console.WriteLine("Enter the Plan ParticipationInProfits:");
                    updatedPlan.ParticipationInProfits = Console.ReadLine();
                   
                    PlanParameters PlanParam = new PlanParameters();

                    Console.WriteLine("Enter the  Plan Age of Entry:");
                    PlanParam.AgeofEntry = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Plan PremiumPayingMode:");
                    PlanParam.PremiumPayingMode = Console.ReadLine();
                    Console.WriteLine("Enter the  Plan Policy Term:");
                    PlanParam.PolicyTerm = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Plan Basic Sum Assured:");
                    PlanParam.BasicSumAssured = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Plan Policy Revival:");
                    PlanParam.PolicyRevival = Console.ReadLine();
                    Console.WriteLine("Enter the Plan Premium Mode Rebate:");
                    PlanParam.PremiumModeRebate = Console.ReadLine();
                    Console.WriteLine("Enter the Plan Loan:");
                    PlanParam.Loan = Console.ReadLine();
                    Console.WriteLine("Enter the Plan Surrender:");
                    PlanParam.Surrender = Console.ReadLine();
                    updatedPlan.PlanParameters = PlanParam;
                    bool planUpdated = InsuranceBAL.ModifyPlanBAL(updatedPlan);
					if (planUpdated)
                    {
                        Console.WriteLine("Plan Details Updated Successfully...");
                    }
                    else
                       Console.WriteLine("Plan Details not Updated...");
                }
            }
            catch (InsurancePlanExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }          
        }

        private static void RemovePlan()
        {           
            try
            {
                string planNo;
                Console.WriteLine("Enter Plan No to Delete:");
                planNo = Console.ReadLine();
                InsurancePlan planDelete = InsuranceBAL.SearchPlanBAL(planNo);
                if (planDelete != null)
                {
                    bool planDeleted = InsuranceBAL.RemovePlanBAL(planNo);
                    Console.WriteLine("Plan Details Deleted Successfully...");
                }
                else
                {
                    Console.WriteLine("Plan Details not Deleted...");
                }
            }
            catch (InsurancePlanExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }            
        }

        private static void GetPlanDetails()
        {
            try
            {
                List<InsurancePlan> plans = InsuranceBAL.GetPlanDetailsBAL();          
                if (plans!=null)
                {                                                       
                    foreach (InsurancePlan plan in plans)
                    {
						Console.WriteLine("**************************************************************************");
						Console.WriteLine("Plan No                        :" + plan.PlanNo);
						Console.WriteLine("Plan Name                      :" + plan.Name);
						Console.WriteLine("Plan Description               :" + plan.Description);
						Console.WriteLine("Plan Death Benefit             :" + plan.DeathBenefit);
						Console.WriteLine("Plan Maturity Benefit          :" + plan.MaturityBenefit);
						Console.WriteLine("ParticipationInProfits         :" + plan.ParticipationInProfits);
						Console.WriteLine("AgeofEntry                     :" + plan.PlanParameters.AgeofEntry);
                        Console.WriteLine("PremiumPayingMode              :" + plan.PlanParameters.PremiumPayingMode);
                        Console.WriteLine("PolicyTerm                     :" + plan.PlanParameters.PolicyTerm);
                        Console.WriteLine("BasicSumAssured                :" + plan.PlanParameters.BasicSumAssured);
                        Console.WriteLine("PolicyRevival                  :" + plan.PlanParameters.PolicyRevival);
                        Console.WriteLine("PremiumModeRebate              :" + plan.PlanParameters.PremiumModeRebate);
                        Console.WriteLine("Loan                           :" + plan.PlanParameters.Loan);
                        Console.WriteLine("Surrender                      :" + plan.PlanParameters.Surrender);
                        Console.WriteLine("***************************************************************************");
					}
                                
                }
                else
                {
                   Console.WriteLine("Plan Details not Available...");
                }
            }
            catch (InsurancePlanExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }           
        }

        private static void SearchPlan()
        {                       
            try
            {
                string planNo;
                Console.WriteLine("Enter Plan No to Search:");
                planNo = Console.ReadLine();
                InsurancePlan searchPlan = InsuranceBAL.SearchPlanBAL(planNo);
                if (searchPlan != null)
                {					
						Console.WriteLine("**************************************************************************");
						Console.WriteLine("Plan No                        :" + searchPlan.PlanNo);
						Console.WriteLine("Plan Name                      :" + searchPlan.Name);
						Console.WriteLine("Plan Description               :" + searchPlan.Description);
						Console.WriteLine("Plan Death Benefit             :" + searchPlan.DeathBenefit);
						Console.WriteLine("Plan Maturity Benefit          :" + searchPlan.MaturityBenefit);
						Console.WriteLine("ParticipationInProfits         :" + searchPlan.ParticipationInProfits);						
                        Console.WriteLine("AgeofEntry                     :" + searchPlan.PlanParameters.AgeofEntry);
                        Console.WriteLine("PremiumPayingMode              :" + searchPlan.PlanParameters.PremiumPayingMode);
                        Console.WriteLine("PolicyTerm                     :" + searchPlan.PlanParameters.PolicyTerm);
                        Console.WriteLine("BasicSumAssured                :" + searchPlan.PlanParameters.BasicSumAssured);
                        Console.WriteLine("PolicyRevival                  :" + searchPlan.PlanParameters.PolicyRevival);
                        Console.WriteLine("PremiumModeRebate              :" + searchPlan.PlanParameters.PremiumModeRebate);
                        Console.WriteLine("Loan                           :" + searchPlan.PlanParameters.Loan);
                        Console.WriteLine("Surrender                      :" + searchPlan.PlanParameters.Surrender);
                        Console.WriteLine("***************************************************************************");
					}
                else
                {
                    throw new InsurancePlanExceptions("Plan Details Not Found");
                }
            }
            catch (InsurancePlanExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }            
        }
		static void Main(string[] args)
		{
			Program PlanDetails = new Program();
			PlanDetails.AcceptPlanDetails();
		}
	}
}
