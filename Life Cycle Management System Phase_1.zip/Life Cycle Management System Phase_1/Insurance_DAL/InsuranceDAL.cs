﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePlan_Entity;
using InsurancePlan_Exceptions;

namespace Insurance_DAL
{
    public class InsuranceDAL
    {
        public static List<InsurancePlan> Plans = new List<InsurancePlan>();
        //public static List<PlanParameters> planParam = new List<PlanParameters>();
        public  bool AddPlanDAL(InsurancePlan plan)
        {
            bool PlanAdded = false;
            try
            {
                Plans.Add(plan);
                PlanAdded = true;
            }
            catch(SystemException ex)
            {
                throw new InsurancePlanExceptions(ex.Message);
            }           
            return PlanAdded;
        }

        public bool ModifyPlanDAL(InsurancePlan plan)
        {
            bool planUpdated = false;
            try
            {
                for (int i = 0; i < Plans.Count; i++)
                {
                    if (Plans[i].PlanNo == plan.PlanNo)
                    {
                        Plans[i].Name = plan.Name;
                        Plans[i].Description = plan.Description;
                        Plans[i].DeathBenefit = plan.DeathBenefit;
                        Plans[i].MaturityBenefit = plan.MaturityBenefit;
                        Plans[i].ParticipationInProfits = plan.ParticipationInProfits;
						//Plans[i].PlanParameters = plan.PlanParameters;
                        Plans[i].PlanParameters.AgeofEntry = plan.PlanParameters.AgeofEntry;
                        Plans[i].PlanParameters.PremiumPayingMode = plan.PlanParameters.PremiumPayingMode;
                        Plans[i].PlanParameters.PolicyTerm = plan.PlanParameters.PolicyTerm;
                        Plans[i].PlanParameters.BasicSumAssured = plan.PlanParameters.BasicSumAssured;
                        Plans[i].PlanParameters.PolicyRevival = plan.PlanParameters.PolicyRevival;
                        Plans[i].PlanParameters.PremiumModeRebate = plan.PlanParameters.PremiumModeRebate;
                        Plans[i].PlanParameters.Loan = plan.PlanParameters.Loan;
                        Plans[i].PlanParameters.Surrender = plan.PlanParameters.Surrender;
                        planUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new InsurancePlanExceptions(ex.Message);
            }
            return planUpdated;
        }

        public  bool RemovePlanDAL(string planNo)
        {
            bool PlanDeleted = false;
            try
            {
                InsurancePlan plans = Plans.Find(p => p.PlanNo == planNo);
                if (plans != null)
                {
                    Plans.Remove(plans);
                    PlanDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new InsurancePlanExceptions(ex.Message);
            }
            return PlanDeleted;
        }

        public List<InsurancePlan> GetPlanDetailsDAL()
        {
            try
            {
                return Plans;

            }
            catch (SystemException ex)
            {
                throw new InsurancePlanExceptions(ex.Message);
            }
        }

        //public List<PlanParameters> GetPlanParamDetailsDAL()
        //{
        //    try
        //    {
        //        return planParam;

        //    }
        //    catch (SystemException ex)
        //    {
        //        throw new InsurancePlanExceptions(ex.Message);
        //    }
        //}

        public  InsurancePlan SearchPlanDAL(string planNo )
        {
            InsurancePlan Plan = null;        
            try
            {
                 Plan = Plans.Find(p => p.PlanNo == planNo);                    
            }
            catch (SystemException ex)
            {
                throw new InsurancePlanExceptions(ex.Message);
            }
            return Plan;
            }

        //public PlanParameters SearchPlanParamDAL(int planNo)
        //{
        //    PlanParameters param = null;
        //    try
        //    {
        //        param = planParam.Find(pm => pm.PlanNo == planNo);
        //    }
        //    catch (InsurancePlanExceptions ipe)
        //    {
        //        throw ipe;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return param;
        //}
    }
}
        

